const app = document.querySelector(".app");

const startButton = document.querySelector(".content__button");

const chooseLevelBox = document.querySelector(".content__level");

const easyButton = document.querySelector(".easy");
const mediumButton = document.querySelector(".medium");
const hardButton = document.querySelector(".hard");

let userLevel;

const suits = ["hearts", "diamonds", "clubs", "spades"];
const ranks = ["6", "7", "8", "9", "10", "J", "Q", "K", "A"];

easyButton.addEventListener("click", (e) => {
  e.preventDefault();
  userLevel = 1;
  console.log(userLevel);
});

mediumButton.addEventListener("click", (e) => {
  e.preventDefault();
  userLevel = 2;
  console.log(userLevel);
});

hardButton.addEventListener("click", (e) => {
  e.preventDefault();
  userLevel = 3;
  console.log(userLevel);
});

startButton.addEventListener("click", (e) => {
  e.preventDefault();
  console.log(userLevel);
  renderPlayField();
});

function renderPlayField() {
  app.textContent = "";

  const playField = document.createElement("div");

  const card = document.createElement("div");
  card.classList.add("card");

  const cardRankTop = document.createElement("p");
  cardRankTop.classList.add("card__rank");

  const cardEmblemTop = document.createElement("svg");
  const cardEmblemCenter = document.createElement("svg");
  const cardEmblemBottom = document.createElement("svg");

  const cardRankBottom = document.createElement("p");
  cardRankBottom.classList.add("card__rank");

  card.appendChild(cardRankTop);
  card.appendChild(cardEmblemTop);
  card.appendChild(cardEmblemCenter);
  card.appendChild(cardEmblemBottom);
  card.appendChild(cardRankBottom);

  playField.appendChild(card);
  app.appendChild(playField);

  // if (level == 1) {
  //     renderCards(playField, 6);
  // } else if (level == 2) {
  //     renderCards(playField, 12);
  // } else if (level == 3) {
  //     renderCards(playField, 18);
  // } else {
  //     alert('Уровень не выбран')
  // }
}

const cards = JSON.parse(data);

function cardTemplateEngine(c) {
  // debugger;
  return {
    tag: "div",
    cls: "card",
    content: [
      {
        tag: "p",
        cls: "card__suit",
        content: c.suits[1],
      },
      {
        tag: "p",
        cls: "card__rank",
        content: c.ranks[1],
      },
    ],
  };
}
playField.appendChild(templateEngine(cards.map((c) => cardTemplateEngine(c))));
