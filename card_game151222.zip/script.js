const app = document.querySelector('.app')

const startButton = document.querySelector('.button__start')

let userLevel
let countdown__numbers
let cardsAmount

const buttons = document.querySelectorAll('.content__level_box')

const clickButton = function (event) {
    const target = event.target
    if (target.classList.contains('easy')) {
        userLevel = 1
        cardsAmount = 3
        console.log(userLevel)
    } else if (target.classList.contains('medium')) {
        userLevel = 2
        cardsAmount = 6
        console.log(userLevel)
    } else if (target.classList.contains('hard')) {
        userLevel = 3
        cardsAmount = 9
        console.log(userLevel)
    }
}
buttons.forEach((element) => {
    element.addEventListener('click', clickButton)
})

startButton.addEventListener('click', (e) => {
    e.preventDefault()
    console.log(userLevel)
    renderPlayField()
})

// function renderTimer() {

//     //Таймер надо доработать - продумать логику его старта
//     //и сделать так, чтобы каждое последующее нажатие не
//     //запускало его заново
//     // playField.addEventListener('click', () => {
//         // let startTime = new Date().getTime()
//         // const timer = setInterval(function () {
//         //     let currentTime = new Date().getTime()
//         //     let gameTime = currentTime - startTime
//         //     console.log(gameTime)
//         //     let days = Math.floor(gameTime / (1000 * 60 * 60 * 24))
//         //     let hours = Math.floor(
//         //         (gameTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
//         //     )
//         //     let minutes = Math.floor(
//         //         (gameTime % (1000 * 60 * 60)) / (1000 * 60)
//         //     )
//         //     let seconds = Math.floor((gameTime % (1000 * 60)) / 1000)

//         //     countdown__numbers.textContent = `${minutes}.${seconds}`
//         // }, 1000)

//     // })

//     for (let i = 0; i < cardsAmount; i++) {
//         const card = document.createElement('div')
//         card.classList.add('card', 'card__closed')
//         playField.appendChild(card)
//         app.appendChild(playField)
//     }
// }

function renderTopContent(container) {
    const topContent = document.createElement('div')
    topContent.classList.add('top')

    const countdown = document.createElement('div')
    countdown.classList.add('countdown')

    const countdown__info = document.createElement('div')
    countdown__info.classList.add('countdown__info')

    const countdown__minutes = document.createElement('p')
    countdown__minutes.classList.add('countdown__text')
    countdown__minutes.textContent = 'min'

    const countdown__seconds = document.createElement('p')
    countdown__seconds.classList.add('countdown__text')
    countdown__seconds.textContent = 'sec'

    countdown__numbers = document.createElement('p')
    countdown__numbers.classList.add('countdown__numbers')
    countdown__numbers.textContent = '00.00'

    countdown.appendChild(countdown__info)
    countdown.appendChild(countdown__numbers)
    countdown__info.appendChild(countdown__minutes)
    countdown__info.appendChild(countdown__seconds)

    const restartButton = document.createElement('button')
    restartButton.classList.add('button', 'button__restart')
    restartButton.textContent = 'Начать заново'

    restartButton.addEventListener('click', () => {
        location.reload()
    })

    topContent.appendChild(countdown)
    topContent.appendChild(restartButton)

    container.appendChild(topContent)
}

function renderPlayField() {
    app.textContent = ''

    renderTopContent(app)

    const cardList = [
        {
            name: '6 hearts',
            img: 'img/6 черви.png',
        },
        {
            name: '7 hearts',
            img: 'img/7 черви.png',
        },
        {
            name: '8 hearts',
            img: 'img/8 черви.png',
        },
        {
            name: '9 hearts',
            img: 'img/9 черви.png',
        },
        {
            name: '10 hearts',
            img: 'img/10 черви.png',
        },
        {
            name: 'J hearts',
            img: 'img/валет черви.png',
        },
        {
            name: 'Q hearts',
            img: 'img/дама черви.png',
        },
        {
            name: 'K hearts',
            img: 'img/король черви.png',
        },
        {
            name: 'A hearts',
            img: 'img/туз черви.png',
        },
        {
            name: '6 diamonds',
            img: 'img/6 бубны.png',
        },
        {
            name: '7 diamonds',
            img: 'img/7 бубны.png',
        },
        {
            name: '8 diamonds',
            img: 'img/8 бубны.png',
        },
        {
            name: '9 diamonds',
            img: 'img/9 бубны.png',
        },
        {
            name: '10 diamonds',
            img: 'img/10 бубны.png',
        },
        {
            name: 'J diamonds',
            img: 'img/валет бубны.png',
        },
        {
            name: 'Q diamonds',
            img: 'img/дама бубны.png',
        },
        {
            name: 'K diamonds',
            img: 'img/король бубны.png',
        },
        {
            name: 'A diamonds',
            img: 'img/туз бубны.png',
        },
        {
            name: '6 clubs',
            img: 'img/6 крести.png',
        },
        {
            name: '7 clubs',
            img: 'img/7 крести.png',
        },
        {
            name: '8 clubs',
            img: 'img/8 крести.png',
        },
        {
            name: '9 clubs',
            img: 'img/9 крести.png',
        },
        {
            name: '10 clubs',
            img: 'img/10 крести.png',
        },
        {
            name: 'J clubs',
            img: 'img/валет крести.png',
        },
        {
            name: 'Q clubs',
            img: 'img/дама крести.png',
        },
        {
            name: 'K clubs',
            img: 'img/король крести.png',
        },
        {
            name: 'A clubs',
            img: 'img/туз крести.png',
        },
        {
            name: '6 spades',
            img: 'img/6 пики.png',
        },
        {
            name: '7 spades',
            img: 'img/7 пики.png',
        },
        {
            name: '8 spades',
            img: 'img/8 пики.png',
        },
        {
            name: '9 spades',
            img: 'img/9 пики.png',
        },
        {
            name: '10 spades',
            img: 'img/10 пики.png',
        },
        {
            name: 'J spades',
            img: 'img/валет пики.png',
        },
        {
            name: 'Q spades',
            img: 'img/дама пики.png',
        },
        {
            name: 'K spades',
            img: 'img/король пики.png',
        },
        {
            name: 'A spades',
            img: 'img/туз пики.png',
        },
    ]

    const range = 35

    let m = {}
    let randomCardIndex = []
    for (let i = 0; i < cardsAmount; ++i) {
        let r = Math.floor(Math.random() * (range - i))
        randomCardIndex.push((r in m ? m[r] : r) + 1)
        randomCardIndex.push((r in m ? m[r] : r) + 1)
        let l = range - i - 1
        m[r] = l in m ? m[l] : l
    }

    function shuffle(array) {
        array.sort(() => Math.random() - 0.5)
    }

    shuffle(randomCardIndex)

    const playField = document.createElement('div')
    playField.classList.add('playField')
    app.appendChild(playField)

    for (let i = 0; i < cardsAmount * 2; i++) {
        let card = document.createElement('img')
        card.classList.add('card')
        card.setAttribute('src', 'img/рубашка.png')
        playField.appendChild(card)
        card.addEventListener('click', () => {
            let j = randomCardIndex[i]
            card.setAttribute('src', `${cardList[j].img}`)
        })
    }
}
