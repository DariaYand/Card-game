[
    'stylelint-config-standard',
    'stylelint-config-prettier',
    'stylelint-prettier/recommended',
]
