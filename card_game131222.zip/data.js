window.data = `
[{
    "6_hearts" : {
        "suit" : "черви",
        "rank" : "6",
        "emblem_url": "img/hearts_top.png"
    },

     "7_черви" : {
        "suit" : "черви",
        "rank" : "7",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "8",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "9",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "10",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "J",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "Q",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "K",
        "emblem_url": "img/hearts_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "черви",
        "rank": "A",
        "emblem_url": "img/hearts_top.png"
    },


    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "6",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "7",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "8",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "9",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "10",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "J",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "Q",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "K",
        "emblem_url": "img/diamonds_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "бубны",
        "rank": "A",
        "emblem_url": "img/diamonds_top.png"
    },


    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "6",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "7",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "8",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "9",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "10",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "J",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "Q",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "K",
        "emblem_url": "img/clubs_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "крести",
        "rank": "A",
        "emblem_url": "img/clubs_top.png"
    },


    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "6",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "7",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "8",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "9",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "10",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "J",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "Q",
        "emblem_url": "img/spades_top.png"
    },

    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "K",
        "emblem_url": "img/spades_top.png"
    },
    
    {
        "card_id" : "8_черви",
        "suit": "пики",
        "rank": "A",
        "emblem_url": "img/spades_top.png"
    }
}
]`
